import time

def BasicLayout():
    print(Board[0] + " | " + Board[1] + " | " + Board[2])
    print()
    print(Board[3] + " | " + Board[4] + " | " + Board[5])
    print()
    print(Board[6] + " | " + Board[7] + " | " + Board[8])

def FullGame():
  Board = ["(a)", "(b)", "(c)",
          "(d)", "(e)", "(f)",
          "(g)", "(h)", "(i)"]

  def display():
    print(Board[0] + " | " + Board[1] + " | " + Board[2])
    print()
    print(Board[3] + " | " + Board[4] + " | " + Board[5])
    print()
    print(Board[6] + " | " + Board[7] + " | " + Board[8])

  print("The game is starting...")
  time.sleep(1)
  print()

  print()
  display() 
  print()

  def RoundX():
    UserChoice = input("Where is your X: ")
    if UserChoice == "a":
      X = 0
    elif UserChoice == "b":
      X = 1
    elif UserChoice == "c":
      X = 2
    elif UserChoice == "d":
      X = 3
    elif UserChoice == "e":
      X = 4
    elif UserChoice == "f":
      X = 5
    elif UserChoice == "g":
      X = 6
    elif UserChoice == "h":
      X = 7
    elif UserChoice == "i":
      X = 8
    del Board[X]
    Board.insert(X, " ❌ ")
    print()
    display()
    print()

  def RoundO():
    UserChoice = input("Where is your O: ")
    if UserChoice == "a":
      O = 0
    elif UserChoice == "b":
      O = 1
    elif UserChoice == "c":
      O = 2
    elif UserChoice == "d":
      O = 3
    elif UserChoice == "e":
      O = 4
    elif UserChoice == "f":
      O = 5
    elif UserChoice == "g":
      O = 6
    elif UserChoice == "h":
      O = 7
    elif UserChoice == "i":
      O = 8
    del Board[O]
    Board.insert(O, " ⭕ ")
    print()
    display()
    print()

  i = 1

  while i == 1:
    RoundX()

    # X winning scenarios

    # X Horizontals
    if Board[0] == " ❌ " and Board[1] == " ❌ " and Board[2] == " ❌ ":
      print(" X Wins!!! ")
      break
    elif Board[3] == " ❌ " and Board[4] == " ❌ " and Board[5] == " ❌ ":
      print(" X Wins!!! ")
      break
    elif Board[6] == " ❌ " and Board[7] == " ❌ " and Board[8] == " ❌ ":
      print(" X Wins!!! ")
      break

    # X Verticals
    if Board[0] == " ❌ " and Board[3] == " ❌ " and Board[6] == " ❌ ":
      print(" X Wins!!! ")
      break
    elif Board[1] == " ❌ " and Board[4] == " ❌ " and Board[7] == " ❌ ":
      print(" X Wins!!! ")
      break
    elif Board[2] == " ❌ " and Board[5] == " ❌ " and Board[8] == " ❌ ":
      print(" X Wins!!! ")
      break

    # X Diagonals
    if Board[0] == " ❌ " and Board[4] == " ❌ " and Board[8] == " ❌ ":
      print(" X Wins!!! ")
      break
    elif Board[2] == " ❌ " and Board[4] == " ❌ " and Board[6] == " ❌ ":
      print(" X Wins!!! ")
      break

    RoundO()

    # O winning scenarios

    # O Horizontals
    if Board[0] == " ⭕ " and Board[1] == " ⭕ " and Board[2] == " ⭕ ":
      print(" O Wins!!! ")
      break
    elif Board[3] == " ⭕ " and Board[4] == " ⭕ " and Board[5] == " ⭕ ":
      print(" O Wins!!! ")
      break
    elif Board[6] == " ⭕ " and Board[7] == " ⭕ " and Board[8] == " ⭕ ":
      print(" O Wins!!! ")
      break

    # O Verticals
    if Board[0] == " ⭕ " and Board[3] == " ⭕ " and Board[6] == " ⭕ ":
      print(" O Wins!!! ")
      break
    elif Board[1] == " ⭕ " and Board[4] == " ⭕ " and Board[7] == " ⭕ ":
      print(" O Wins!!! ")
      break
    elif Board[2] == " ⭕ " and Board[5] == " ⭕ " and Board[8] == " ⭕ ":
      print(" O Wins!!! ")
      break

    # O Diagonals
    if Board[0] == " ⭕ " and Board[4] == " ⭕ " and Board[8] == " ⭕ ":
      print(" O Wins!!! ")
      break
    elif Board[2] == " ⭕ " and Board[4] == " ⭕ " and Board[6] == " ⭕ ":
      print(" O Wins!!! ")
      break

  print()
  PlayAgain = input("Do you want to play again? (y/n) : ")
  if PlayAgain.lower() == "y":
    FullGame()
  elif PlayAgain.lower() == "n":
    print()
    time.sleep(1)
    print("THANKS FOR PLAYING!")


print("Welcome to Tic Tac Toe!")
print()
time.sleep(1)
print("- - - - - - - - - - ")
print()

FullGame()

